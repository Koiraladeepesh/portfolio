import { Router } from 'express'
import { pool } from '../db.js'

const router = Router()

router.post('/', async (req, res) => {
  const { name, email, subject, message } = req.body

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email, and message are required' })
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Invalid email address' })
  }

  try {
    await pool.query(
      `INSERT INTO messages (name, email, subject, message)
       VALUES ($1, $2, $3, $4)`,
      [name, email, subject || '', message]
    )
    console.log(`[contact] new message from ${name} <${email}>`)
    res.json({ success: true })
  } catch (err) {
    console.error('[contact] error:', err)
    res.status(500).json({ error: 'Failed to save message' })
  }
})

export default router
